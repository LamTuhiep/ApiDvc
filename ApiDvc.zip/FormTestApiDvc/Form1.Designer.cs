﻿namespace FormTestApiDvc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLog = new System.Windows.Forms.TextBox();
            this.btnTaoHS = new System.Windows.Forms.Button();
            this.txtQuery = new System.Windows.Forms.TextBox();
            this.btnTruyVan = new System.Windows.Forms.Button();
            this.btnDanhSachDvc = new System.Windows.Forms.Button();
            this.btnHoanThanh = new System.Windows.Forms.Button();
            this.btnLay1DVC = new System.Windows.Forms.Button();
            this.btnTruyVanByDate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(12, 90);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(471, 352);
            this.txtLog.TabIndex = 0;
            // 
            // btnTaoHS
            // 
            this.btnTaoHS.Location = new System.Drawing.Point(12, 22);
            this.btnTaoHS.Name = "btnTaoHS";
            this.btnTaoHS.Size = new System.Drawing.Size(75, 23);
            this.btnTaoHS.TabIndex = 1;
            this.btnTaoHS.Text = "Tạo hồ sơ";
            this.btnTaoHS.UseVisualStyleBackColor = true;
            this.btnTaoHS.Click += new System.EventHandler(this.btnTaoHS_Click);
            // 
            // txtQuery
            // 
            this.txtQuery.Location = new System.Drawing.Point(12, 64);
            this.txtQuery.Name = "txtQuery";
            this.txtQuery.Size = new System.Drawing.Size(345, 20);
            this.txtQuery.TabIndex = 2;
            // 
            // btnTruyVan
            // 
            this.btnTruyVan.Location = new System.Drawing.Point(373, 62);
            this.btnTruyVan.Name = "btnTruyVan";
            this.btnTruyVan.Size = new System.Drawing.Size(88, 23);
            this.btnTruyVan.TabIndex = 3;
            this.btnTruyVan.Text = "Truy vấn hồ sơ";
            this.btnTruyVan.UseVisualStyleBackColor = true;
            this.btnTruyVan.Click += new System.EventHandler(this.btnTruyVan_Click);
            // 
            // btnDanhSachDvc
            // 
            this.btnDanhSachDvc.Location = new System.Drawing.Point(110, 22);
            this.btnDanhSachDvc.Name = "btnDanhSachDvc";
            this.btnDanhSachDvc.Size = new System.Drawing.Size(118, 23);
            this.btnDanhSachDvc.TabIndex = 4;
            this.btnDanhSachDvc.Text = "Danh sách thủ tục DVC";
            this.btnDanhSachDvc.UseVisualStyleBackColor = true;
            this.btnDanhSachDvc.Click += new System.EventHandler(this.btnDanhSachDvc_Click);
            // 
            // btnHoanThanh
            // 
            this.btnHoanThanh.Location = new System.Drawing.Point(397, 22);
            this.btnHoanThanh.Name = "btnHoanThanh";
            this.btnHoanThanh.Size = new System.Drawing.Size(166, 23);
            this.btnHoanThanh.TabIndex = 5;
            this.btnHoanThanh.Text = "Hoàn thành (đã trả hồ sơ)";
            this.btnHoanThanh.UseVisualStyleBackColor = true;
            this.btnHoanThanh.Click += new System.EventHandler(this.btnHoanThanh_Click);
            // 
            // btnLay1DVC
            // 
            this.btnLay1DVC.Location = new System.Drawing.Point(249, 22);
            this.btnLay1DVC.Name = "btnLay1DVC";
            this.btnLay1DVC.Size = new System.Drawing.Size(118, 23);
            this.btnLay1DVC.TabIndex = 6;
            this.btnLay1DVC.Text = "Lấy 1 thủ tục DVC";
            this.btnLay1DVC.UseVisualStyleBackColor = true;
            this.btnLay1DVC.Click += new System.EventHandler(this.btnLay1DVC_Click);
            // 
            // btnTruyVanByDate
            // 
            this.btnTruyVanByDate.Location = new System.Drawing.Point(467, 62);
            this.btnTruyVanByDate.Name = "btnTruyVanByDate";
            this.btnTruyVanByDate.Size = new System.Drawing.Size(109, 23);
            this.btnTruyVanByDate.TabIndex = 7;
            this.btnTruyVanByDate.Text = "Truy vấn theo ngày";
            this.btnTruyVanByDate.UseVisualStyleBackColor = true;
            this.btnTruyVanByDate.Click += new System.EventHandler(this.btnTruyVanByDate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 454);
            this.Controls.Add(this.btnTruyVanByDate);
            this.Controls.Add(this.btnLay1DVC);
            this.Controls.Add(this.btnHoanThanh);
            this.Controls.Add(this.btnDanhSachDvc);
            this.Controls.Add(this.btnTruyVan);
            this.Controls.Add(this.txtQuery);
            this.Controls.Add(this.btnTaoHS);
            this.Controls.Add(this.txtLog);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.Button btnTaoHS;
        private System.Windows.Forms.TextBox txtQuery;
        private System.Windows.Forms.Button btnTruyVan;
        private System.Windows.Forms.Button btnDanhSachDvc;
        private System.Windows.Forms.Button btnHoanThanh;
        private System.Windows.Forms.Button btnLay1DVC;
        private System.Windows.Forms.Button btnTruyVanByDate;
    }
}

