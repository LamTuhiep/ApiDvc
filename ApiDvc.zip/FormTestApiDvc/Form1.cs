﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows.Forms;
using ApiDvc.API;
using ApiDvc.Contract;
using ApiDvc.Contract.Data;
using FormTestApiDvc.Properties;
using Newtonsoft.Json;
using RockBase.Settings.FromJson;

namespace FormTestApiDvc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private IApiDvcClient _apiDvcClient;

        private string _maDonVi = "HTPVITHANH";
        private void Form1_Load(object sender, EventArgs e)
        {
            var url = Settings.Default.FeatureSettingPath;
            //lấy settings từ file json cấu hình 
            var settings = JsonSettings.Use();
            var apiOptions =
                settings.ReadSettings<ApiOptions>(Settings.Default.FeatureSettingPath);

            //khởi tạo client truy xuất cổng dvc
            _apiDvcClient = ApiFactory.CreateClient(apiOptions);
        }
        private void btnTaoHS_Click(object sender, EventArgs e)
        {
            //lấy thông tin thủ tục từ cổng dvc
            var dvc = LayMauDichVuCong(_maDonVi, txtQuery.Text.Trim());

            if (dvc == null)
            {
                return;
            }

            //thông tin hồ sơ để tạo mới trên cổng dvc
            var hoso = new HoSoMoi()
            {
                MaDonVi = _maDonVi,
                MaTTHC = dvc.MaDichVu,
                TenTTHC =dvc.TenDichVu ,
                MaMauHS = dvc.MaMauDichVu,
                TenNguoiNop = "patsoft",
                SoCCCD = "123456789",
                DiaChi = "ko co",
                DienThoai = "0901234567",
                NgayTao = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"),
                NoiNhanKetQua = "Tỉnh Hậu Giang",
                TraTaiATM = HoSoAtm.NhanTaiAtm,
                NhanTaiATM = HoSoAtm.NhanTaiAtm
            };
            // var json =JsonConvert.SerializeObject(hoso, Formatting.Indented);
            // txtLog.AppendText(json);

            txtLog.AppendText($"TaoMoi ==================================================" + Environment.NewLine);

            //gọi api tạo mới hồ sơ trên cổng dvc
            var result = _apiDvcClient.TaoMoiHoSo(hoso);

            if (result.IsSuccess) //thành công
            {
                txtLog.AppendText(result.Value + Environment.NewLine);
            }
            else //thất bại
            {
                result.Errors.ForEach(error =>
                {
                    txtLog.AppendText(error.Message + Environment.NewLine);
                });
            }
        }

        private DichVuCong LayMauDichVuCong(string maDonVi, string maDichVuCong)
        {
            var result = _apiDvcClient.LayMauThuTucDvc(maDonVi, maDichVuCong);
            if (result.IsSuccess)
            {
                return result.Value;
            }
            txtLog.AppendText($"Khong tim thay ma dvc, {String.Join(", ",result.Errors.Select(e=>e.Message))}");
            return null;
        }

        

        private void btnDanhSachDvc_Click(object sender, EventArgs e)
        {
            var result = _apiDvcClient.DanhSachThuTucDvc(_maDonVi);
            if (result.IsFailed)
            {
                txtLog.AppendText($"Loi mnr, {String.Join(", ", result.Errors.Select(error => error.Message))}" + Environment.NewLine);
                return;
            }

            txtLog.AppendText($"DanhSachDVC ==================================================" + Environment.NewLine);
            var dsach = JsonConvert.SerializeObject(result.Value, Formatting.Indented);
            txtLog.AppendText(dsach + Environment.NewLine);
        }

        private void btnHoanThanh_Click(object sender, EventArgs e)
        {
            var maHoSo = txtQuery.Text.Trim();
            var result = _apiDvcClient.CapNhatTienDoHoSo(maHoSo, _maDonVi);
            if (result.IsFailed)
            {
                txtLog.AppendText($"Loi mnr, {String.Join(", ", result.Errors.Select(error => error.Message))}" + Environment.NewLine);
                return;
            }
            txtLog.AppendText($"HoanThanh ==================================================" + Environment.NewLine);
            txtLog.AppendText(result.Value + Environment.NewLine);
        }

        private void btnLay1DVC_Click(object sender, EventArgs e)
        {
            txtLog.AppendText($"Lay1DVC ==================================================" + Environment.NewLine);
            var dvc =  LayMauDichVuCong(_maDonVi, txtQuery.Text.Trim());
            var data = JsonConvert.SerializeObject(dvc, Formatting.Indented);
            txtLog.AppendText(data + Environment.NewLine);
        }
        private void btnTruyVan_Click(object sender, EventArgs e)
        {
            //tạo query string, truy vấn thông tin 1 hổ sơ cụ thể thì phải truyển mã hồ sơ và mã đơn vị.
            var query = new QueryDossiersRequest()
            {
                dossierNo = txtQuery.Text.Trim(),
                searchGovAgencyCode= _maDonVi
            };

            // var result = await _apiDvcClient.TruyVanHoSoAsync(query);
            var result = _apiDvcClient.TruyVanHoSo(query);
            if (result.IsFailed)
            {
                txtLog.AppendText($"Loi mnr, {String.Join(", ", result.Errors.Select(error => error.Message))}" + Environment.NewLine);
                return;
            }
            txtLog.AppendText($"TruyVan ==================================================" + Environment.NewLine);
            txtLog.AppendText($"Total: {result.Value.Count}" + Environment.NewLine);

            var data = JsonConvert.SerializeObject(result.Value, Formatting.Indented);

            txtLog.AppendText(data + Environment.NewLine);
        }
        private void btnTruyVanByDate_Click(object sender, EventArgs e)
        {
            //truy vấn theo ngày
            var query = new QueryDossiersRequest()
            {
                order = "false",
                searchGovAgencyCode = _maDonVi,

                FilterDate = new FilterByReceiveDate()
                {
                    From = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("dd/MM/yyyy"),
                    To = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 10).ToString("dd/MM/yyyy")
                }

                // FilterDate = new FilterByReleaseDate()
                // {
                //     From = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("dd/MM/yyyy"),
                //     To = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 10).ToString("dd/MM/yyyy")
                // }

                // FilterDate = new FilterByFinishDate()
                // {
                //     From = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("dd/MM/yyyy"),
                //     To = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 10).ToString("dd/MM/yyyy")
                // }
            };

            // var result = await _apiDvcClient.TruyVanHoSoAsync(query);
            var result = _apiDvcClient.TruyVanHoSo(query);
            if (result.IsFailed)
            {
                txtLog.AppendText($"Loi mnr, {String.Join(", ", result.Errors.Select(error => error.Message))}" + Environment.NewLine);
                return;
            }
            txtLog.AppendText($"TruyVan ==================================================" + Environment.NewLine);
            txtLog.AppendText($"Total: {result.Value.Count}" + Environment.NewLine);

            var data = JsonConvert.SerializeObject(result.Value, Formatting.Indented);

            txtLog.AppendText(data + Environment.NewLine);
        }
    }
}
