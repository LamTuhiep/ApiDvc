﻿using ApiDvc.Contract.Data;
using FluentResults;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ApiDvc.Contract
{
    public interface IApiDvcClient
    {
        /// <summary>
        /// Dùng để truy vấn thông tin chi tiết của hồ sơ trên cổng DVC (gồm tình trạng xử lý, các ngày...)
        /// </summary>
        /// <param name="query">Dùng tạo query string, chỉ cần truyền các thuộc tính cần thiết cho các loại query, không cần truyền tất cả</param>
        /// <returns>Trả về danh sách hồ sơ thỏa điều kiện</returns>
        Result<List<ChiTietDichVuCong>> TruyVanHoSo(QueryDossiersRequest query);
        Task<Result<List<ChiTietDichVuCong>>> TruyVanHoSoAsync(QueryDossiersRequest query);

        /// <summary>
        /// Lấy cụ thể 1 mẫu thủ tục dịch vụ công, hoạt động dựa trên kết quả của <code>DanhSachThuTucDvcAsync</code>.
        /// </summary>
        /// <param name="maDonVi">Mã đơn vị</param>
        /// <param name="maThuTuc">Mã thủ tục</param>
        /// <returns>DichVuCong</returns>
        Result<DichVuCong> LayMauThuTucDvc(string maDonVi, string maThuTuc);
        Task<Result<DichVuCong>> LayMauThuTucDvcAsync(string maDonVi, string maThuTuc);

        /// <summary>
        /// Lấy danh sách dịch vụ trên cổng DVC hỗ trợ nhận trả tại ATM theo mã đơn vị.
        /// </summary>
        /// <param name="maDonVi">Mã đơn vị</param>
        /// <returns>Danh sách dịch vụ công nhận trả lại ATM</returns>
        Result<List<DichVuCong>> DanhSachThuTucDvc(string maDonVi);
        Task<Result<List<DichVuCong>>> DanhSachThuTucDvcAsync(string maDonVi);

        /// <summary>
        /// Tạo mới hồ sơ trên cổng dịch vụ công.
        /// </summary>
        /// <returns>Nếu thành công trả về mã hồ sơ trên cổng DVC, nếu lỗi trả về thông tin lỗi</returns>
        Result<string> TaoMoiHoSo(HoSoMoi hoSo);
        Task<Result<string>> TaoMoiHoSoAsync(HoSoMoi hoSo);

        /// <summary>
        /// Cập nhật trạng thái hoàn thành cho hồ sơ trên cổng DVC sau khi người dân lấy hồ sơ tại máy ATM
        /// </summary>
        /// <param name="maHoSo">Mã hồ sơ</param>
        /// <param name="maDonVi">Mã đơn vị</param>
        /// <returns>Nếu thành công trả về mã hồ sơ, nếu lỗi trả về thông tin lỗi</returns>
        Result<string> CapNhatTienDoHoSo(string maHoSo, string maDonVi);
        Task<Result<string>> CapNhatTienDoHoSoAsync(string maHoSo, string maDonVi);
    }
}
