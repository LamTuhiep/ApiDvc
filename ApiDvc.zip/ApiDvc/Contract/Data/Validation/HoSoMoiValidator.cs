﻿using FluentValidation;

namespace ApiDvc.Contract.Data.Validation
{
    public class HoSoMoiValidator : AbstractValidator<HoSoMoi>
    {
        public HoSoMoiValidator()
        {
            RuleFor(p => p.MaTTHC).NotEmpty();
            RuleFor(p => p.TenTTHC).NotEmpty();
            RuleFor(p => p.MaDonVi).NotEmpty();
            RuleFor(p => p.TenNguoiNop).NotEmpty();
            RuleFor(p => p.SoCCCD).NotEmpty().Must(l => l.Length == 9 || l.Length == 12);
            RuleFor(p => p.DienThoai).NotEmpty();
            RuleFor(p => p.DiaChi).NotEmpty();
            RuleFor(p => p.NgayTao).NotEmpty();
            RuleFor(p => p.NoiNhanKetQua).NotEmpty();
            RuleFor(p => p.NhanTaiATM).NotEmpty();
            RuleFor(p => p.TraTaiATM).NotEmpty();
            RuleFor(p => p.MaMauHS).NotEmpty();
        }
    }
}
