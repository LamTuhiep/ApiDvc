﻿namespace ApiDvc.Contract.Data
{
    public class ChiTietDichVuCong : DichVuCong
    {
        public string MaHoSo { get; set; }
        public string MaTinhTrang { get; set; }
        public string TenTinhTrang { get; set; }
        public string TenNguoiNop { get; set; }
        public string SoCccd { get; set; }
        public string DienThoai { get; set; }
        public string DiaChi { get; set; }
        public string NgayNop { get; set; }
        public string NgayTiepNhan { get; set; }
        public string NgayDenHan { get; set; }
        public string NgayTra { get; set; }
        public string NgayHoanThanh { get; set; }

    }
}
