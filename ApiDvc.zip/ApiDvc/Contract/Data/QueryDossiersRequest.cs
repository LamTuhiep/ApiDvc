﻿using System;
using System.Collections.Generic;

namespace ApiDvc.Contract.Data
{
    public class QueryDossiersRequest
    {
        public string order { get; set; } = "true";
        public string dossierNo { get; set; }
        public string searchGovAgencyCode { get; set; }
        public FilterDate FilterDate { get; set; }

    }

    #region FilterDate

    public abstract class FilterDate
    {
        public string From { get; set; }
        public string To { get; set; }
        public abstract string GetQueryString();
    }

    public class FilterByReceiveDate : FilterDate
    {
        public override string GetQueryString()
        {
            return $"fromReceiveDate={From}&toReceiveDate={To}";
        }
    }
    public class FilterByReleaseDate : FilterDate
    {
        public override string GetQueryString()
        {
            return $"fromReleaseDate={From}&toReleaseDate={To}";
        }
    }
    public class FilterByFinishDate : FilterDate
    {
        public override string GetQueryString()
        {
            return $"fromFinishDate={From}&toFinishDate={To}";
        }
    }

    #endregion



    public static class QueryDossiersRequestUtil
    {
        public static string GetQueryString(this QueryDossiersRequest queryDossiersRequest)
        {
            var propString = new List<string>();
            foreach (var propertyInfo in queryDossiersRequest.GetType().GetProperties())
            {
                if (propertyInfo.GetValue(queryDossiersRequest,null) != null && propertyInfo.PropertyType != typeof(FilterDate) )
                {
                    if (!string.IsNullOrEmpty(propertyInfo.GetValue(queryDossiersRequest, null).ToString()))
                    {
                        propString.Add($"{propertyInfo.Name}={propertyInfo.GetValue(queryDossiersRequest, null)}");
                    }
                }
            }

            if (queryDossiersRequest.FilterDate != null)
            {
                propString.Add(queryDossiersRequest.FilterDate.GetQueryString());
            }

            if (propString.Count > 0)
            {
                return "?" + string.Join("&", propString);
            }
            return String.Empty;
        }
    }
}
