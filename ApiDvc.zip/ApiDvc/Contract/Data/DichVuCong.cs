﻿namespace ApiDvc.Contract.Data
{
    public class DichVuCong
    {
        public string MaDichVu { get; set; }
        public string TenDichVu { get; set; }
        public string MaMauDichVu { get; set; }
        public string MaDonVi { get; set; }
        public string TenDonVi { get; set; }

    }
}
