﻿using System;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ApiDvc.Contract.Data
{
    public class HoSoMoi
    {
        public string RequestId => Guid.NewGuid().ToString();
        
        public string MaTTHC { get; set; }
        public string TenTTHC { get; set; }
        public string MaDonVi { get; set; }
        public string TenNguoiNop { get; set; }
        public string SoCCCD { get; set; }
        public string DienThoai { get; set; }
        public string DiaChi { get; set; }
        public string NgayTao { get; set; }
        public string NoiNhanKetQua { get; set; }
        public string MaMauHS { get; set; }
        public HoSoAtm NhanTaiATM { get; set; }
        public HoSoAtm TraTaiATM { get; set; }
    }

    [JsonConverter(typeof(StringEnumConverter))]
    public enum HoSoAtm
    {
        [EnumMember(Value = "1")]
        KhongNhanTaiAtm = 1,
        [EnumMember(Value = "2")]
        NhanTaiAtm = 2
    }
}
