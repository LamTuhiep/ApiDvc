﻿using System;
using System.Collections.Generic;
using System.Text;
using ApiDvc.Contract.Data;

namespace ApiDvc.API.Data
{
    public class MauDichVuCong
    {
        public string GovAgencyCode { get; set; }
        public string ServiceCode { get; set; }
        public string GovAgencyName { get; set; }
        public string ServiceName { get; set; }
        public string ContactName { get; set; }
        public string ContactTelNo { get; set; }
        public string Address { get; set; }
        public string ApplicantName { get; set; }
        public string ApplicantIdNo { get; set; }
        public string DossierNo { get; set; }
        public string DossierStatus { get; set; }
        public string DossierStatusText { get; set; }
        public string SubmitDate { get; set; }
        public string ReceiveDate { get; set; }
        public string DueDate { get; set; }
        public string ReleaseDate { get; set; }
        public string FinishDate { get; set; }

        public List<Option> Options { get; set; }

        public class Option
        {
            public string TemplateNo { get; set; }
            public string TemplateName { get; set; }
            public string OptionName { get; set; }

        }
    }

    public static class MauDichVuCongUtil
    {
        public static ChiTietDichVuCong ToChiTietDichVuCong(this MauDichVuCong mauDichVuCong)
        {
            return new ChiTietDichVuCong()
            {
                MaHoSo = mauDichVuCong.DossierNo,
                MaDichVu = mauDichVuCong.ServiceCode,
                TenDichVu = mauDichVuCong.ServiceName,
                MaDonVi = mauDichVuCong.GovAgencyCode,
                TenDonVi = mauDichVuCong.GovAgencyName,
                TenNguoiNop = mauDichVuCong.ContactName,
                DienThoai = mauDichVuCong.ContactTelNo,
                SoCccd = mauDichVuCong.ApplicantIdNo,
                DiaChi = mauDichVuCong.Address,
                NgayNop = mauDichVuCong.SubmitDate,
                NgayTiepNhan = mauDichVuCong.ReceiveDate,
                NgayDenHan = mauDichVuCong.DueDate,
                NgayTra = mauDichVuCong.ReleaseDate,
                NgayHoanThanh = mauDichVuCong.FinishDate,
                MaTinhTrang = mauDichVuCong.DossierStatus,
                TenTinhTrang = mauDichVuCong.DossierStatusText
            };
        }
    }
}
