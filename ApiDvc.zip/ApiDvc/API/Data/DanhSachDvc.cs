﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ApiDvc.API.Data
{
    public class DanhSachDvc
    {
        public int Total { get; set; }
        public List<MauDichVuCong> Data { get; set; }
    }
}
