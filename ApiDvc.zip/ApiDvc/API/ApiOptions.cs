﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.Http;
using System.Text;

namespace ApiDvc.API
{
    
    public class ApiOptions
    {
        public BasicAuth Authentication { get; set; }

        public ApiUrl Url { get; set; }

        public class BasicAuth
        {
            public string Username { get; set; }
            public string Password { get; set; }
        }

        public class ApiUrl
        {
            public string Base { get; set; }
            public string TaoMoiHoSo { get; set; }
            public string CapNhatTienDoHoSo { get; set; }
            public string DanhSachDichVuCong { get; set; }
            public string TruyVanHoSo { get; set; }
        }
    }
}
