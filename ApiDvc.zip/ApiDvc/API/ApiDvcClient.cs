﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using ApiDvc.API.Data;
using ApiDvc.Contract;
using ApiDvc.Contract.Data;
using ApiDvc.Contract.Data.Validation;
using FluentResults;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;
using static ApiDvc.API.Data.MauDichVuCong;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace ApiDvc.API
{
    
    public class ApiDvcClient : IApiDvcClient, IDisposable
    {
        private RestClient _client;
        private ApiOptions.ApiUrl _url;
        private ApiOptions _options;

        public ApiDvcClient(ApiOptions options)
        {
            _url = options.Url;
            _options=options;
            var restOptions = new RestClientOptions(options.Url.Base)
            {
                Authenticator =
                    new HttpBasicAuthenticator(options.Authentication.Username, options.Authentication.Password)
            };

            _client = new RestClient(restOptions);
            _client.AddDefaultHeader(KnownHeaders.Accept, "application/json");
        }

        public Result<List<ChiTietDichVuCong>> TruyVanHoSo(QueryDossiersRequest query)
        {
            return Task.Run(() => TruyVanHoSoAsync(query)).GetAwaiter().GetResult();
        }

        public async Task<Result<List<ChiTietDichVuCong>>> TruyVanHoSoAsync(QueryDossiersRequest query)
        {
            try
            {
                var queryString = query.GetQueryString();
                var request = new RestRequest(_url.TruyVanHoSo + queryString);
                // request.AddOrUpdateHeader("groupId", "96351");
                var response = await _client.ExecuteAsync(request);

                if (response.IsSuccessful)
                {
                    if (response.Content != null)
                    {

                        var data= JsonConvert.DeserializeObject<DanhSachDvc>(response.Content);
                        var chiTietDvc= data.Data.Select(d=>d.ToChiTietDichVuCong()).ToList();
                        return Result.Ok(chiTietDvc);
                    }

                    return Result.Fail($"TruyVanHoSoAsync failed, {response.Content}");
                }

                return Result.Fail(
                    $"TruyVanHoSoAsync failed, {response.StatusCode} {response.StatusDescription}, {response.Content}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Result.Fail(new Error("TruyVanHoSoAsync failed").CausedBy(e));
            }
        }

        public Result<DichVuCong> LayMauThuTucDvc(string maDonVi, string maThuTuc)
        {
            return Task.Run(() => LayMauThuTucDvcAsync(maDonVi, maThuTuc)).GetAwaiter().GetResult();
        }

        public async Task<Result<DichVuCong>> LayMauThuTucDvcAsync(string maDonVi, string maThuTuc)
        {
            try
            {
                var dsResult = await DanhSachThuTucDvcAsync(maDonVi);
                if (dsResult.IsFailed)
                {
                    return Result.Fail(string.Join(", ", dsResult.Errors.Select(e=>e.Message)));
                }
                
                var dvc = dsResult.Value.Single(d=>d.MaDichVu==maThuTuc);
                return dvc;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Result.Fail(new Error("LayMauThuTucDvcAsync failed").CausedBy(e));
            }
        }

        public Result<List<DichVuCong>> DanhSachThuTucDvc(string maDonVi)
        {
            return Task.Run(() => DanhSachThuTucDvcAsync(maDonVi)).GetAwaiter().GetResult();
        }

        public async Task<Result<List<DichVuCong>>> DanhSachThuTucDvcAsync(string maDonVi)
        {
            try
            {
                var url_para = $"?searchGovAgencyCode={maDonVi}&postAtmService=true&receiveATMService=true";
                var request = new RestRequest(_url.DanhSachDichVuCong+url_para);
                var response=await _client.ExecuteAsync<DanhSachDvc>(request);

                if (response.IsSuccessful)
                {
                    if (response.Data !=null)
                    {
                        var dvc = response.Data.Data.Select(d =>
                            new DichVuCong()
                            {
                                MaDichVu = d.ServiceCode,
                                TenDichVu = d.ServiceName,
                                MaMauDichVu = d.Options.First().TemplateNo,
                                MaDonVi = d.GovAgencyCode,
                                TenDonVi = d.GovAgencyName
                            }
                        ).ToList();
                        return Result.Ok(dvc);
                    }

                    return Result.Fail($"DanhSachThuTucDvcAsync failed, {response.Content}");
                }

                return Result.Fail(
                    $"DanhSachThuTucDvcAsync failed, {response.StatusCode} {response.StatusDescription}, {response.ErrorMessage} {response.ErrorException?.InnerException?.Message}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return Result.Fail(new Error("DanhSachThuTucDvcAsync failed").CausedBy(e));
            }
        }

        public Result<string> TaoMoiHoSo(HoSoMoi hoSo)
        {
            return Task.Run(() => TaoMoiHoSoAsync(hoSo)).GetAwaiter().GetResult();
        }

        public async Task<Result<string>> TaoMoiHoSoAsync(HoSoMoi hoSo)
        {
            var validator = new HoSoMoiValidator();
            var valResult = await validator.ValidateAsync(hoSo);
            if (!valResult.IsValid)
            {
                return Result.Fail($"{nameof(hoSo)} is not valid,{JsonSerializer.Serialize(valResult.ToDictionary())}");
            }

            var request = new RestRequest(_url.TaoMoiHoSo, Method.Post);
            request.AddOrUpdateHeader(KnownHeaders.ContentType, "application/json");

            var body = JsonConvert.SerializeObject(hoSo);
            request.AddStringBody(body,ContentType.Json);
            
            var response= await _client.ExecuteAsync<ResponseMessage>(request);

            if (!response.IsSuccessful)
            {
                return Result.Fail($"TaoMoiHoSoAsync failed,{response.StatusCode} {response.StatusDescription}, {response.Content}");
            }

            if (response.Data?.error_code!="0")
            {
                return Result.Fail(
                    $"TaoMoiHoSoAsync failed,{response.StatusCode} {response.StatusDescription}, {response.Content}");
            }

            if (string.IsNullOrEmpty(response.Data.MaHoSo))
            {
                return Result.Fail(
                    $"TaoMoiHoSoAsync failed, MaHoSo trả về rỗng");
            }

            return response.Data.MaHoSo;
        }

        public Result<string> CapNhatTienDoHoSo(string maHoSo, string maDonVi)
        {
            return Task.Run(() => CapNhatTienDoHoSoAsync(maHoSo, maDonVi)).GetAwaiter().GetResult();
        }

        public async Task<Result<string>> CapNhatTienDoHoSoAsync(string maHoSo, string maDonVi)
        {
            var request = new RestRequest(_url.CapNhatTienDoHoSo, Method.Post);
            request.AddOrUpdateHeader(KnownHeaders.ContentType, "application/json");

            //lưu ý tên biến phải viết đúng hoa thường so với tài liệu hướng dẫn, ko thì sẽ bị lỗi Method Not Allowed.
            var body = JsonConvert.SerializeObject(new { MaHoSo = maHoSo, Madonvi = maDonVi });
            request.AddStringBody(body,ContentType.Json);

            var response = await _client.ExecuteAsync<ResponseMessage>(request);
            if (!response.IsSuccessful)
            {
                return Result.Fail($"CapNhatTienDoHoSoAsync failed,{response.StatusCode} {response.StatusDescription}, {response.Content}");
            }

            if (response.Data?.error_code != "0")
            {
                return Result.Fail(
                    $"CapNhatTienDoHoSoAsync failed,{response.StatusCode} {response.StatusDescription}, {response.Content}");
            }

            return Result.Ok(maHoSo);
        }

        public void Dispose()
        {
            _client?.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
