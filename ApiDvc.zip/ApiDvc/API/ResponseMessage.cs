﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApiDvc.API
{
    public class ResponseMessage
    {
        public string error_code { get; set; }
        public string message { get; set;}
        public string MaHoSo { get; set; }

    }
}
