﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using ApiDvc.Contract;

namespace ApiDvc.API
{
    public class ApiFactory
    {
        
        public static IApiDvcClient CreateClient(ApiOptions options)
        {
            var api = new ApiDvcClient(options);
            return api;
        }
    }
}
